module.exports = {

    token: "MTA2NjMxMTM0NTc5ODEzNTg3OA.G-D3w6.WwEZYH-SCQfqQWmVZuiHFpe3n8-dCsCb8GfAgA",
    prefix: ".",
    sahip: "852664248638898196",
    durum: ".gg/mernistr",

    api: {
        TCKN: "http://localhost/zirvedebiraktik/tc.php?auth_token=qwertyzz&",
        TC_GSM: "http://localhost/zirvedebiraktik/tcgsm.php?auth_token=qwertyzz&",
        GSM_TC: "http://localhost/zirvedebiraktik/gsmtc.php?auth_token=qwertyzz&",
        AD_SOYAD: "http://localhost/zirvedebiraktik/adsoyad.php?auth_token=qwertyzz&",
        AILEA: "localhost/zirvedebiraktik/soyagaci.php?qwertyzz&",
        AILEB: "localhost/zirvedebiraktik/soyagaci2.php?qwertyzz&",
        DDOS: "",
        SECMEN_TCKN: "",
        SECMEN_AD_SOYAD: "",
        AOL: "",
        ASI: "",
        AD: "http://localhost/zirvedebiraktik/ad.php?auth_token=qwertyzz&",
        SOYAD: "http://localhost/zirvedebiraktik/soyad.php?auth_token=qwertyzz&",
        IKAMETGAH: ""
    },

    emojiler: {
        UPLOAD: "<:evilinkralicesi:1044987516278812713>"
    },

    roller: {
        admin: "1053404931236843540",
        vip: "1064211916521746544",
        premium: "1064213596558590064",
        booster: "1032408258213851148",
        limitlirol: "1064205051628888185",
        freemium: "",
        yardimci: "1065721276909502564"
    },

    log: "https://discord.com/api/webhooks/1065395706757644410/in9QMnG91Oneckv4KAe06k8qDGhEXL0Z-9cGclPju21BtFWry4sTf2sQjKZ4-0PBSU3F",
    log2: "https://discord.com/api/webhooks/1065395733315993600/1HVeid9CjFrQyeWzltIs6wEhWZxflbAezHjmlvjhwDYZFlQGpDLYazzyoAAkVu7kxOM-",

    wl: [""], // log tutmaz - rowy farkı ;)

    sunucuID: "1030585428757192755",
    kanal: ["1066332007711379466"],
    seskanal: "1064677419526660187",

    sorgulimit: "600",

    bakim: ""
}