module.exports = {

    token: "MTA4OTI2MDM0MDI1NDA4MTAyNA.GXc8Ix.aY-h9KxmCSld4Sfh7osjcdv1pe0H5Nv4bVWcts",  // BOTUN TOKENİ
    prefix: ".",
    sahip: "840439077316198470",  // BOTUN SAHİBİ
    durum: "hash.com.tr",

    api: {
        TCKN: "http://141.95.12.114/zirvedebiraktik/tc.php?auth_token=qwertyzz&",
        TC_GSM: "http://141.95.12.114/zirvedebiraktik/tcgsm.php?auth_token=qwertyzz&",
        GSM_TC: "http://141.95.12.114/zirvedebiraktik/gsmtc.php?auth_token=qwertyzz&",
        AD_SOYAD: "http://141.95.12.114/zirvedebiraktik/adsoyad.php?auth_token=qwertyzz&",
        AILEA: "http://141.95.12.114/soyagaci.php?qwertyzz&",
        AILEB: "http://141.95.12.114/soyagaci2.php?qwertyzz&",
        DDOS: "",
        SECMEN_TCKN: "",
        SECMEN_AD_SOYAD: "",
        AOL: "",
        ASI: "",
        AD: "http://141.95.12.114/zirvedebiraktik/ad.php?auth_token=qwertyzz&",
        SOYAD: "http://141.95.12.114/zirvedebiraktik/soyad.php?auth_token=qwertyzz&",
        IKAMETGAH: ""
    },

    emojiler: {
        UPLOAD: "<:bacaksiz31ci:1089263709274247248>"
    },

    roller: {
        admin: "1063460816197779486", // ADMİN ROLÜNÜN İD
        vip: "1089263271242113056", // VİP ROLÜNÜN İD
        premium: "1089262950998626425", // PREMİUM ROÜLÜNÜN İD
        booster: "1089262551948333066",
        limitlirol: "1064163532595286048",
        freemium: "1064163532595286048",
        yardimci: ""
    },

    log: "https://discord.com/api/webhooks/1072650505135849472/YxkPNifvu4DXXsTn1T_qNybDahn80_vkdpdHfRg5DE6sKS9xfApUN9toCRyfnTcoW5bR",  //WEB HOOK LİNKİNİ BURAYA KOYCAN LOG 
    log2: "",

    wl: [""], // log tutmaz - rowy farkı ;)

    sunucuID: "1063442370244386897",
    kanal: ["1089261710457716786"],
    seskanal: "1089262209571496006",

    sorgulimit: "5",

    bakim: ""
}